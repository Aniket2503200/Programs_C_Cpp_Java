
class Program236
{
    public static void main(String Arg[])
    {
        System.out.println("Jay Ganesh..");
    }
}