#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *next;
};

typedef struct node NODE;
typedef struct node* PNODE;
typedef struct node** PPNODE;

//void InsertFirst(PPNODE Head, int no)
void Push(PPNODE Head, int no)
{

}

//void DeleteFirst(PPNODE Head)
int Pop(PPNODE Head)
{

}

void Display(PNODE Head)
{

}

int main()
{
    PNODE first = NULL;


    return 0;
}